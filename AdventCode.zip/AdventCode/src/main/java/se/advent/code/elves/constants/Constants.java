package se.advent.code.elves.constants;

public class Constants {

    public static final String FILE_NAME = "ElvesCalory.txt";

}
